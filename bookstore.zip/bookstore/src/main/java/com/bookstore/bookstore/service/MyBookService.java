package com.bookstore.bookstore.service;

import com.bookstore.bookstore.entity.MyBookList;

public interface MyBookService {
	
	public void saveMyBooks(MyBookList mybooks);
	

}
